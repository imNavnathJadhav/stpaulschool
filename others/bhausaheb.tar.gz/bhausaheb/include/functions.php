<?php
//get customer deduction
function get_customer_deduct($cid){
	require("db.php");
	$sql = "SELECT * FROM tbl_reductions where cid='$cid'";
	//mysql_query();
	$conn->query("SET NAMES utf8");
	mysqli_set_charset($conn,"utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}else{
		return 0;
	}
	$conn->close();
}

function get_halls($id=""){
	require("db.php");
	$sql = "SELECT * FROM tbl_halls";
	if($id!=""){
		$sql=$sql." where id='$id'";
	}
	//mysql_query();
	$conn->query("SET NAMES utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}
	$conn->close();
}
function get_types($id=""){
	require("db.php");
	$sql = "SELECT * FROM tbl_types";
	if($id!=""){
		$sql=$sql." where id='$id'";
	}
	$conn->query("SET NAMES utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}
	$conn->close();
}
function get_customers($id=""){
	require("db.php");
	//$sql = "SELECT tbl_customers.*,tbl_halls.name as halls_name, tbl_halls.location as halls_location, tbl_types.name as types_name FROM tbl_customers c join tbl_halls h ON c.hall=h.id JOIN tbl_types t ON c.type=t.id ORDER BY c.id DESC";
	$sql="SELECT tbl_customers.*,tbl_halls.name as halls_name, tbl_halls.location as halls_location, tbl_types.name as types_name FROM tbl_customers LEFT JOIN tbl_halls ON tbl_halls.id = tbl_customers.hall LEFT JOIN tbl_types ON tbl_types.id = tbl_customers.type";
	if($id!=""){
		$sql.=" WHERE tbl_customers.id='$id'";
	}else{
		$sql.=" ORDER BY tbl_customers.id DESC";
	}
	
	mysqli_set_charset($conn,"utf8");
	$conn->query("SET NAMES utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}
	$conn->close();
}
function get_customers_record(){
    require("db.php");
	//$sql = "SELECT tbl_customers.*,tbl_halls.name as halls_name, tbl_halls.location as halls_location, tbl_types.name as types_name FROM tbl_customers c join tbl_halls h ON c.hall=h.id JOIN tbl_types t ON c.type=t.id ORDER BY c.id DESC";
	$sql="SELECT tbl_customers.*,tbl_halls.name as halls_name, tbl_halls.location as halls_location, tbl_types.name as types_name FROM tbl_customers LEFT JOIN tbl_halls ON tbl_halls.id = tbl_customers.hall LEFT JOIN tbl_types ON tbl_types.id = tbl_customers.type  ORDER BY tbl_customers.id ASC";
	mysqli_set_charset($conn,"utf8");
	$conn->query("SET NAMES utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}
	$conn->close();
}
function get_reductions($id){
	require("db.php");
	$sql = "SELECT * from tbl_reductions WHERE cid='$id'";
	//mysql_query();
	$conn->query("SET NAMES utf8");
	mysqli_set_charset($conn,"utf8");
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
		// output data of each row
		return $result;
	}
	$conn->close();
}

//save
function save_type($data){
	require("db.php");
	$name=stripslashes($data['name']);
	
	$sql = "INSERT INTO tbl_types(name)VALUES('$name')";
	//mysql_query();
	$conn->query("SET NAMES utf8");
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
	$conn->close();
}
function save_hall($data){
	require("db.php");
	$name=stripslashes($data['name']);
	$address=stripslashes($data['address']);
	
	$sql = "INSERT INTO tbl_halls(name,location)
	VALUES('$name','$address')";
	//mysql_query();
	$conn->query("SET NAMES utf8");
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
	$conn->close();
}
function save_customer_deduct($data){
	require("db.php");
	$cid=$data['cid'];
	$reason=stripslashes($data['note']);
	$amount=stripslashes($data['am_amount']);
	$type=$data['amtype'];
	$date=$data['date'];
	
	$sql = "INSERT INTO tbl_reductions(reason,date,amount,type,cid)
	VALUES('$reason','$date','$amount','$type','$cid')";
	//mysql_query();
	$conn->query("SET NAMES utf8");
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
	$conn->close();
}

function save_customer_data($data){
	require("db.php");
	$data2=array();
	foreach($data as $k=>$v){
		$data2[$k]=addslashes($v);
	}
	$weights=array();
	$not=array('name','mobile','hall','type','rate','address','final_total');
	foreach($data2 as $key=>$value){
		if(in_array($key,$not)){
			continue;
		}
		$weights[$key]=addslashes($value);
	}
	$weights=serialize($weights);
	//print_r($data2);
	$name=$data2['name'];
	$address=$data2['address'];
	$mobile=$data2['mobile'];
	$type=$data2['type'];
	$hall=$data2['hall'];
	$final_weight=$data2['final_total'];
	$rate=$data2['rate'];
	$price=0.00;
	if(isset($rate) OR $rate!=""){
		$a=$final_weight/100;
		//$a=floor($a);
		$price=$a*$rate;
		$price=(int)$price;
	}
	$sql = "INSERT INTO tbl_customers(name, address, mobile, type, hall, weights, final_weight, rate, price)
	VALUES ('$name', '$address', '$mobile', '$type', '$hall', '".$weights."', '$final_weight', '$rate', '$price')";

	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}
function save_customer_edited_data($data){
	require("db.php");
	$data2=array();
	foreach($data as $k=>$v){
		$data2[$k]=addslashes($v);
	}
	$weights=array();
	$not=array('name','mobile','hall','type','rate','address','final_total','cid');
	foreach($data2 as $key=>$value){
		if(in_array($key,$not)){
			continue;
		}
		$weights[$key]=addslashes($value);
	}
	$weights=serialize($weights);
	//print_r($data2);
	$id=$data2['cid'];
	$name=$data2['name'];
	$address=$data2['address'];
	$mobile=$data2['mobile'];
	$type=$data2['type'];
	$hall=$data2['hall'];
	$final_weight=$data2['final_total'];
	$rate=$data2['rate'];
	$price=0.00;
	if(isset($rate) OR $rate!=""){
		$a=$final_weight/100;
		//$a=floor($a);
		$price=$a*$rate;
		$price=(int)$price;
	}
	$sql = "UPDATE tbl_customers SET name='$name', address='$address', mobile='$mobile', type='$type', hall='$hall', weights='".$weights."', final_weight='$final_weight', rate='$rate', price='$price' WHERE id='$id'";
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}
function save_hall_edited_data($data){
	require("db.php");
	$data2=array();
	foreach($data as $k=>$v){
		$data2[$k]=addslashes($v);
	}
	//print_r($data2);
	$id=$data2['cid'];
	$name=$data2['name'];
	$address=$data2['address'];
	
	$sql = "UPDATE tbl_halls SET name='$name', location='$address' WHERE id='$id'";
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}
function save_type_edited_data($data){
	require("db.php");
	$data2=array();
	foreach($data as $k=>$v){
		$data2[$k]=addslashes($v);
	}
	//print_r($data2);
	$id=$data2['cid'];
	$name=$data2['name'];
	
	$sql = "UPDATE tbl_types SET name='$name' WHERE id='$id'";
	mysqli_set_charset($conn,"utf8");
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}

function delete_customer($id){
	require("db.php");
	$id=addslashes($id);
	$sql = "DELETE FROM tbl_customers WHERE id='$id'";
	$sql2 = "DELETE FROM tbl_reductions WHERE cid='$id'";
	if ($conn->query($sql) === TRUE AND $conn->query($sql2) === TRUE) {
		return true;
	} else {
		return false;
	}
}
function delete_hall($id){
	require("db.php");
	$id=addslashes($id);
	$sql = "DELETE FROM tbl_halls WHERE id='$id'";
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}
function delete_type($id){
	require("db.php");
	$id=addslashes($id);
	$sql = "DELETE FROM tbl_types WHERE id='$id'";
	if ($conn->query($sql) === TRUE) {
		return true;
	} else {
		return false;
	}
}
?>