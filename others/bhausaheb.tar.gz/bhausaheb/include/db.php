<?php
$servername = "localhost";
$username = "hiwaleco_bhau";
$password = "I08H-gT]L(0q";
$dbname = "hiwaleco_bhausaheb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("इंटरनेट चालू करा : " . $conn->connect_error);
}