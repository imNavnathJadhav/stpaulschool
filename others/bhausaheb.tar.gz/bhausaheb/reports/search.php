<?php
require("../include/check_user.php");
require("../include/db.php");
$main_sql="SELECT tbl_customers.*,tbl_halls.name as halls_name, tbl_halls.location as halls_location, tbl_types.name as types_name FROM tbl_customers LEFT JOIN tbl_halls ON tbl_halls.id = tbl_customers.hall LEFT JOIN tbl_types ON tbl_types.id = tbl_customers.type";
$sub_sql="";
$date_sql="";
if(!empty($_POST['type'])){
	$type=$_POST['type'];
	$sub_sql= " AND type='$type' " ;
}
if(!empty($_POST['hall'])){
	$hall=$_POST['hall'];
	$sub_sql.= " AND hall='$hall' " ;
}
if(!empty($_POST['rate'])){
	$rate=$_POST['rate'];
	$sub_sql.= " AND rate='$rate' " ;
}
if(!empty($_POST['from_date'])){
	$from=date('Y-m-d',strtotime($_POST['from_date']));
	$date_sql= " AND DATE(added_on) >='$from' " ;
}
if(!empty($_POST['to_date'])){
	$to=date('Y-m-d',strtotime($_POST['to_date']));
	$date_sql= " AND DATE(added_on) <='$to' " ;
}
if(!empty($_POST['from_date']) AND !empty($_POST['to_date'])){
	//$sql= " AND dt between  '$dt1' AND '$dt2'  " ;
	
	$from=date('Y-m-d',strtotime($_POST['from_date']));
	$to=date('Y-m-d',strtotime($_POST['to_date']));
	$date_sql=" AND DATE(added_on) BETWEEN '$from' AND '$to'";
}
$sub_sql=$sub_sql.$date_sql;
$sub_sql=preg_replace("/AND/","WHERE",$sub_sql,1); // Remove first  AND with WHERE
$sql=$main_sql.$sub_sql;
mysqli_set_charset($conn,"utf8");
$conn->query("SET NAMES utf8");
$result = $conn->query($sql);
if ($result->num_rows > 0) {
	// output data of each row
	if($result){
		?>
		<table id="example" class="row-border hover order-column display responsive no-wrap" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th class="text-left">अनु. क्र.</th>
					<th class="text-left">खातेदाराचे नाव</th>
					<th class="text-left">पत्ता</th>
					<th class="text-left">मोबाइल</th>
					<th class="text-left">मालाचा प्रकार</th>
					<th class="text-left">तारीख व वेळ</th>
					<th class="text-left">गोडावून</th>
					<th class="text-right">भाव</th>
					<th class="text-right">वजन</th>
					<th class="text-right">रुपये</th>
				</tr>
			</thead>
			<tbody>
		<?php
		while($row = $result->fetch_assoc()) {
		?>
		<tr>
		<td class="text-left"><?=$row['id']?></td>
		<td class="text-left"><?=$row['name']?></td>
		<td class="text-left"><?=$row['address']?></td>
		<td class="text-left"><?=$row['mobile']?></td>
		<td class="text-left"><?=$row['types_name']?></td>
		<td class="text-left"><?=date("d-m-y g:i:s A",strtotime($row['added_on']))?></td>
		<td class="text-left"><?=$row['halls_name']?></td>
		<td class="text-right"><?=$row['rate']?></td>
		<td class="text-right"><?=$row['final_weight']?></td>
		<td class="text-right"><?=number_format((int)$row['price'])?></td>
		</tr>
		<?php
		}
		?>
		</tbody>
			<tfoot>
				<tr>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th class="text-right"></th>
				<th class="text-right"></th>
				</tr>
			</tfoot>
			</table>
		<?php
		}else{
			echo "0";
		}
}else{
	echo "0";
}
$conn->close();
?>