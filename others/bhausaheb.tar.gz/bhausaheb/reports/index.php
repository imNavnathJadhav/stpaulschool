<?php
require("../include/head.php");
require("../include/functions.php");
$types=get_types();
$halls=get_halls();
$results=get_customers_record();
?>

<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.2.13/semantic.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.16/css/dataTables.semanticui.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.semanticui.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/colreorder/1.5.0/css/colReorder.semanticui.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.2/css/responsive.semanticui.min.css"/>
<link rel="stylesheet" type="text/css" href="/bhausaheb/assets/css/bootstrap-datepicker.min.css"/>
<style>
	td.highlight {
	background-color: whitesmoke !important;
}
/*body{
		background-image: linear-gradient(0deg, #138808 33%, #ffffff 33%, #ffffff 66%, #FF9933 66% );
}*/
</style>
<div class="container" style="top-margin:20px">
	<div class="row" >
			<div class="col-md-4"style="margin-top:10px;">
				<select class="form-control" name="type" id="type">
					<option value="">सर्व माल</option>
					<?php
					if($types){
					while($row = $types->fetch_assoc()) {
						echo "<option value='".$row['id']."'>".$row['name']."</option>";
					}
					}
					?>
				</select>
			</div>
			<div class="col-md-4"style="margin-top:10px;">
				<select class="form-control" name="hall" id="hall">
					<option value="">सर्व गोडावून</option>
					<?php
					if($halls){
					while($row = $halls->fetch_assoc()) {
						echo "<option value='".$row['id']."'>".$row['name']." (".$row['location'].")"."</option>";
					}
					}
					?>
				</select>
			</div>
			<div class="col-md-4"style="margin-top:10px;">
				<input type="number" placeholder="भाव" id="rate" class="form-control" name="rate">
			</div>
			<div class="col-md-4"style="margin-top:10px;">
				<input type="text" id="from" placeholder="तारीखी पासून" class="form-control" name="from">
			</div>
			<div class="col-md-4"style="margin-top:10px;">
				<input type="text" id="to" placeholder="तारीखी पर्यंत" class="form-control" name="to">
			</div>
			<div class="col-md-4"style="margin-top:10px;">
				<input type="button" id="search" class="btn btn-info" value="Search">
			</div>
		<div class="col-md-12" style="margin-top:20px;" id="tbl_body">
			<table id="example" class="row-border hover order-column display responsive no-wrap" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th class="text-left">अनु. क्र.</th>
					<th class="text-left" style="width:200">खातेदाराचे नाव </th>
					<th class="text-left">पत्ता</th>
					<th class="text-left">मोबाइल</th>
					<th class="text-left">मालाचा प्रकार</th>
					<th class="text-left">&nbsp;&nbsp;तारीख &nbsp;&nbsp;</th>
					<th class="text-left">गोडावून</th>
					<th class="text-right">भाव</th>
					<th class="text-right">वजन</th>
					<th class="text-right">रुपये</th>
				</tr>
			</thead>
			<tbody>
			<?php
				if($results){
				    $sr=1;
					while($row = $results->fetch_assoc()) {
					?>
				<tr>
					<td class="text-left"><?=$sr++?></td>
					<td class="text-left"><?=$row['name']?></td>
					<td class="text-left"><?=$row['address']?></td>
					<td class="text-left"><?=$row['mobile']?></td>
					<td class="text-left"><?=$row['types_name']?></td>
					<td class="text-left"><?=date("d-m-y",strtotime($row['added_on']))?></td>
					<td class="text-left"><?=$row['halls_name']?></td>
					<td class="text-right"><?=$row['rate']?></td>
					<td class="text-right"><?=$row['final_weight']?></td>
					<td class="text-right"><?=number_format((int)$row['price'])?></td>
				</tr>
				<?php
					}}
				?>
			</tbody>
			<tfoot>
				<tr>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th></th>
				<th class="text-right"></th>
				<th class="text-right"></th>
				</tr>
			</tfoot>
			</table>
		</div>
	</div>	
</div>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/select/1.2.5/js/dataTables.select.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.colVis.min.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/dataTables.semanticui.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.semanticui.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.2/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.2/js/responsive.semanticui.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/colreorder/1.5.0/js/dataTables.colReorder.min.js"></script>
<script type="text/javascript" src="/bhausaheb/assets/js/bootstrap-datepicker.min.js"></script>
<script>
$(document).ready(function() {
	
	$("#search").click(function(){
		var a=false;
		$('#type, #hall, #rate, #from, #to').each(function() {
		if ($(this).val() != '') {
			a=true;
		}});
		if(a){
			$("#search").val("Loading...");
			var type=$("#type").val();
			var hall=$("#hall").val();
			var rate=$("#rate").val();
			var from_date=$("#from").val();
			var to_date=$("#to").val();
			$.ajax({
				url:"search.php",
				type:"POST",
				data:{type:type,hall:hall,rate:rate,from_date:from_date,to_date:to_date},
				success:function(res){
					if(res==0){
						alert("कोणताही रेकॉर्ड सापडला नाही.");
						//return;
					}else{
						$("#tbl_body").empty();
						$("#tbl_body").append(res);
						activate();
					}
					$("#search").val("Search");
				},
			});
		}else{
			return false;
		}
	});
	$('#from,#to').datepicker({
    format: "yyyy/mm/dd",
    daysOfWeekHighlighted: "0"
	});
	//$(".buttons-print").remove();
	//$(".buttons-html5").remove();
	//$("#example_filter").after('<div class="col-md-12"><div class="row"><div class="dt-buttons ui basic buttons"><button class="ui button buttons-print" tabindex="0" aria-controls="example"><span>Print</span></button><button class="ui button buttons-copy buttons-html5" tabindex="0" aria-controls="example"><span>Copy</span></button><button class="ui button buttons-excel buttons-html5" tabindex="0" aria-controls="example"><span>Excel</span></button><button class="ui button buttons-csv buttons-html5" tabindex="0" aria-controls="example"><span>CSV</span></button><button class="ui button buttons-pdf buttons-html5" tabindex="0" aria-controls="example"><span>PDF</span></button><button class="ui button buttons-print" tabindex="0" aria-controls="example"><span>Print all (not just selected)</span></button></div></div></div>');
	//$(".dt-button").eq(2).nextAll().remove();
	activate();	
    } );
	
function number_format (number, decimals, decPoint, thousandsSep)
{
	number = (number + '').replace(/[^0-9+\-Ee.]/g, '')
	var n = !isFinite(+number) ? 0 : +number
	var prec = !isFinite(+decimals) ? 0 : Math.abs(decimals)
	var sep = (typeof thousandsSep === 'undefined') ? ',' : thousandsSep
	var dec = (typeof decPoint === 'undefined') ? '.' : decPoint
	var s = ''

	var toFixedFix = function (n, prec) {
	if (('' + n).indexOf('e') === -1) {
	  return +(Math.round(n + 'e+' + prec) + 'e-' + prec)
	} else {
	  var arr = ('' + n).split('e')
	  var sig = ''
	  if (+arr[1] + prec > 0) {
		sig = '+'
	  }
	  return (+(Math.round(+arr[0] + 'e' + sig + (+arr[1] + prec)) + 'e-' + prec)).toFixed(prec)
	}
	}

	// @todo: for IE parseFloat(0.55).toFixed(0) = 0;
	s = (prec ? toFixedFix(n, prec).toString() : '' + Math.round(n)).split('.')
	if (s[0].length > 3) {
	s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep)
	}
	if ((s[1] || '').length < prec) {
	s[1] = s[1] || ''
	s[1] += new Array(prec - s[1].length + 1).join('0')
	}
	return s.join(dec)
}
	function activate(){
    var table=$('#example').DataTable( {
		/*"order": [[ 0, "desc" ]],*/
		"language": {
            "sProcessing":   "प्रक्रिया चालू आहे ...",
			"sLengthMenu":   " _MENU_ प्रविष्टियां दिखाएं ",
			"sZeroRecords":  "कोणताही रेकॉर्ड सापडला नाही",
			"sInfo":         "_START_ to _END_ of _TOTAL_ रेकॉर्ड दाखवत आहे",
			"sInfoEmpty":    "0 रेकॉर्डपैकी 0 ते 0 दर्शवित आहे",
			"sInfoFiltered": "(_MAX_ एकूण रेकॉर्डपैकी फिल्टर केलेले)",
			"sInfoPostFix":  "",
			"sSearch":       "शोधा:",
			"sUrl":          "",
			"oPaginate": {
				"sFirst":    "पहिला",
				"sPrevious": "मागील",
				"sNext":     "पुढे",
				"sLast":     "शेवटचे"
			}
        },
        dom: 'Bfrtip',
        responsive: {
			details: true
		},
        colReorder: true,
        scrollY:true,
    deferRender:    true,
    scroller:     true,
        columnDefs: [
            {
                targets: 1,
                className: 'noVis'
            }
        ],
        lengthMenu: [
            [ 10, 25, 50, -1 ],
            [ '10 rows', '25 rows', '50 rows', 'Show all' ]
        ],
        buttons: [
            {
                extend: 'colvis',
                columns: ':not(.noVis)'
            },
            'pageLength',
            { extend: 'print',title: 'भाऊसाहेब ट्रेडर्स अहवाल', footer: true,exportOptions: {columns: ':visible'} },
             { extend: 'copyHtml5',title: 'भाऊसाहेब ट्रेडर्स अहवाल', footer: true ,exportOptions: {columns: ':visible'}},
            { extend: 'excelHtml5',title: 'भाऊसाहेब ट्रेडर्स अहवाल', footer: true,exportOptions: {columns: ':visible'} },
            { extend: 'csvHtml5',title: 'भाऊसाहेब ट्रेडर्स अहवाल', footer: true,exportOptions: {columns: ':visible'} },
            { extend: 'pdfHtml5',title: 'Bhausaheb Traders Reports', "charset": "utf-8",  footer: true,exportOptions: {columns: ':visible'} },
            {
                extend: 'print',
                footer:true,
                text: 'Print all (not just selected)',
                exportOptions: {
                    modifier: {
                        selected: false
                    }
                }
            },
        ],
        select: true,
		"footerCallback": function ( row, data, start, end, display ) {
            var api = this.api(), data;
 
            // Remove the formatting to get integer data for summation
            var intVal = function ( i ) {
                return typeof i === 'string' ?
                    i.replace(/[\$,]/g, '')*1 :
                    typeof i === 'number' ?
                        i : 0;
            };
 
            // Total over all pages
            total = api
			.column( 8, { page: 'current'} )
			.data()
			.reduce( function (a, b) {
			return intVal(a) + intVal(b);
			}, 0 );
			rupees = api
			.column( 9, { page: 'current'} )
			.data()
			.reduce( function (a, b) {
			return intVal(a) + intVal(b);
			}, 0 );
			// Update footer
			$( api.column(8).footer() ).html(
			'एकूण वजन '+ total
			);
			$( api.column(9).footer() ).html(
			'एकूण रुपये '+number_format(rupees)
			);
        },
    } );
    table.buttons().container()
        .appendTo( $('div.nine.column:eq(2)', table.table().container()) );
        $('#example tbody')
        .on( 'mouseenter', 'td', function () {
            var colIdx = table.cell(this).index().column;
 
            $( table.cells().nodes() ).removeClass( 'highlight' );
            $( table.column( colIdx ).nodes() ).addClass( 'highlight' );
        } );
	}
</script>
<?php
include("../include/footer.php");
?>
