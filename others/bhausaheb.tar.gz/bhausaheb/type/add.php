<?php
require("../include/head.php");
?>
<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="../assets/css/responsive.css" type="text/css" />
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<form role="form" action="save_type.php" class="form-inline" method="post" id="halls" name="halls">
			<div class="form-horizontal">
				<div class="form-group">
				  <div class="col-xs-12">
					<div class="form-inline">
					  <div class="form-group">
						<input type="text" id="name" name="name" class="form-control" placeholder="मालाचे नाव" required />
					  </div>
					</div>
				  </div>
				</div>
				<button type="submit" class="btn btn-success" id="save">जतन करा/Save</button>
			</div>
		</form>
	</div>
</div>
<?php
include("../include/footer.php");
?>