<?php
require("include/check_user.php");
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-MR" xml:lang="en-MR">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" /> 
	<meta http-equiv="content-language" content="en-MR" />
	<meta name="author" content="Navnath Jadhav" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>भाऊसाहेब ट्रेडर्स - मांडगाव</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" >
	<style type='text/css'>
	.form-inline .form-group {
	  margin-left: 0;
	  margin-right: 0;
	}
	body {
	padding-bottom: 20px;
	}

	.navbar {
	margin-bottom: 20px;
	}
	</style>
	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
	<a class="navbar-brand" href="/bhausaheb">भाऊसाहेब ट्रेडर्स</a>
	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	</button>
	<div class="collapse navbar-collapse" id="navbarSupportedContent">
		<ul class="navbar-nav mr-auto">
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					खाते
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					<a class="dropdown-item" href="/bhausaheb/customers/add.php">नवीन खातेदार जोडा</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="/bhausaheb/customers/">उपलब्ध खातेदार</a>
				</div>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					मालाचा प्रकार
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					<a class="dropdown-item" href="/bhausaheb/type/add.php">नवीन मालाचा प्रकार जोडा</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="/bhausaheb/type/">उपलब्ध मालाचा प्रकार</a>
				</div>
			</li>
			<li class="nav-item dropdown">
				<a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
					गोडावून
				</a>
				<div class="dropdown-menu" aria-labelledby="navbarDropdown">
					<a class="dropdown-item" href="/bhausaheb/halls/add.php">नवीन गोडावून जोडा</a>
					<div class="dropdown-divider"></div>
					<a class="dropdown-item" href="/bhausaheb/halls/">उपलब्ध गोडावून</a>
				</div>
			</li>
			<li class="nav-item">
				<a class="nav-link" href="/bhausaheb/reports/">सर्व अहवाल</a>
			</li>
			<li class="nav-item active">
				<a class="nav-link" href="/bhausaheb/logout.php">साइन आउट </a>
			</li>
		</ul>
		<form class="form-inline my-2 my-lg-0" action="search.php">
			<input class="form-control mr-sm-2" type="search" name="q" placeholder="Search" aria-label="Search">
			<button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
		</form>
	</div>
</nav>
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<div class="col-md-12 text-center" style="margin-top:20px;">
			Welcome <?=$_SESSION['user']?>
		</div>
		<div class="col-md-12 text-center" style="margin-top:20px;">
			श्री गिरजा माता प्रसन्ना
		</div>
		<div class="col-md-12 text-center" style="margin-top:20px;">
			<img src="uploads/girjamata.jpg" class="img-fluid" alt="Girja Mata Photo">
		</div>
	</div>	
</div>
</body>
</html>