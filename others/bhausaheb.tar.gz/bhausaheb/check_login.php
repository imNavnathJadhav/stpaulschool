<?php
session_start();
require("include/db.php");
$name=$_POST['uname'];
$pass=$_POST['psw'];
$pass=md5($pass);
$sql="SELECT * from tbl_login where username='$name' AND password='$pass'";
$conn->query("SET NAMES utf8");
mysqli_set_charset($conn,"utf8");
$result = $conn->query($sql);
if ($result->num_rows == 1) {
	// output data of each row
	$row=$result->fetch_assoc();
	$conn->close();
	$_SESSION['user']=$row['name'];
	header("Location:/bhausaheb/");
}else{
    $conn->close();
    header("Location:/bhausaheb/login.php?s=0");   
}
?>