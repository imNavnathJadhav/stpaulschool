<?php
require("../include/head.php");
require("../include/functions.php");
$types=get_types();
$halls=get_halls();
?>
	<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
	<link rel="stylesheet" href="../assets/css/responsive.css" type="text/css" />
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<div class="form-horizontal">
			<div class="form-group">
			  <div class="col-xs-12">
				<div class="form-inline">
				  <div class="form-group">
					<input type="text" id="name" name="name" class="form-control" placeholder="खातेदाराचे नाव" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" id="address" name="address" placeholder="पत्ता" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" name="mobile" id="mobile" placeholder="मोबाइल नंबर" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" name="rate" id="rate" value="" placeholder="भाव" />
				  </div>
				  <div class="form-group">
					<select class="form-control" name="type" id="type">
					<option value="">मालाचा प्रकार निवडा</option>
					<?php
					if($types){
					while($row = $types->fetch_assoc()) {
						echo "<option value='".$row['id']."'>".$row['name']."</option>";
					}
					}
					?>
					</select>
				  </div>
				  <div class="form-group">
					<select class="form-control" name="hall" id="hall">
					<option value="">गोडावून निवडा</option>
					<?php
					if($halls){
					while($row = $halls->fetch_assoc()) {
						echo "<option value='".$row['id']."'>".$row['name']." (".$row['location'].")"."</option>";
					}
					}
					?>
					</select>
				  </div>
				  <div class="form-group">
					&nbsp;तारीख :&nbsp;<b id="date"></b>&nbsp;&nbsp;वेळ  :&nbsp;<b id="time"></b>
				  </div>
				</div>
			  </div>
			</div>
			<button class="btn btn-info" id="add">अधिक जोडा/Add Columns</button>
			<button class="btn btn-danger" id="reset">रीसेट करा/Reset</button>
			<button class="btn btn-success" id="save">जतन करा/Save</button>
			<button class="btn btn-primary" id="print">मुद्रित करा/Print</button>
		</div>
	</div>
	<form role="form" action="save_customer.php" class="form-inline" method="post" id="weights" name="weights">
		<div class="row" id="row">
			<input type="hidden" id="nos" value="10">
			<div class="col" style="margin-top:20px">
				<div class="form-group">
					<label class="control-label col-sm-1">1)</label>
					<div class="col-sm-2">
						<input type="number" id="1" onkeyup="changed(this,10)" name="1" class="form-control" >
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">2)</label>
					<div class="col-sm-2"><!--if(this.value.length==2){document.getElementById(Number(this.id)+1).focus();}-->
						<input type="number" name="2" id="2" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">3)</label>
					<div class="col-sm-2">
						<input type="number" name="3" id="3" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">4)</label>
					<div class="col-sm-2">
						<input type="number" name="4" id="4" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">5)</label>
					<div class="col-sm-2">
						<input type="number" name="5" id="5" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control" >
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">6)</label>
					<div class="col-sm-2">
						<input type="number" name="6" id="6" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">7)</label>
					<div class="col-sm-2">
						<input type="number" name="7" id="7" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control" >
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">8)</label>
					<div class="col-sm-2">
						<input type="number" name="8" id="8" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control">
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">9)</label>
					<div class="col-sm-2">
						<input type="number" name="9" id="9" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control" >
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">10)</label>
					<div class="col-sm-2">
						<input type="number" name="10" id="10" maxlength="2" pattern="[0-9]" onkeyup="changed(this,10)" class="form-control" >
					</div>
				</div>
				<div class="form-group">
					<label class="control-label col-sm-1">Total</label>
					<div class="col-sm-2">
						<input type="text" name="total10" value="0" id="total10" class="form-control" readonly>
					</div>
				</div>
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-inline">
				  <div class="form-group">
				  <label class="control-label col-md-3">एकूण वजन</label>
					<input type="text" name="final_total" id="final_total" class="form-control" value="0" readonly />
				  </div>
			</div>
	</form>
</div>
<?php
include("../include/footer.php");
?>
<!---भाव
आपण भाव टाकलेला नाही, तरीही पुढे जाऊ ईच्छिता का?
यशस्वीपणे सेव झाला
मालाचा प्रकार निवडा
गोडावून निवडा
रोडवरचा गोडावून
मांडगाव
पिंपळाखालचा गोडावून
मांगवाड्याकडचा गोडावून
सिल्लोडचा गोडावून
गोडावून
सिल्लोड
मक्का
ज्वारी
कापूस
आहे
आणि
कुंट्टल
खातेदारांचे
काढुण टाकला आहे
काढण्यात
काढायाचा
काढल्यावर
घेणे
देणे
निली
ट्रेडर्स
ौ ै ा ी ू ब ह ग द ज ड ़ ॉ ो े ् ि ु प र क त च ट  ं म न व ल स , . य ॉ 
		औ ऐ आ ई ऊ भ ङ घ ध झ ढ ञ ऑ ओ ए अ इ उ फ ऱ ख थ छ ठ  ँ ण   ळ श ष । ।
-->
<script>
function activate(){
	/*$("input").focus(function(){
		$(this).prop('readonly', false);
	});*/
	$("input").change(function(){
		$(this).prop('readonly', true);
	});
}
$(document).ready(function(){
	
	$("#save").click(function(){
		if($("#name").val()==""){
			alert("कृपया खातेदाराचे नाव टाका");
			$("#name").focus();
			return;
		}
		if($("#address").val()==""){
			alert("कृपया खातेदाराचा पत्ता टाका");
			$("#address").focus();
			return;
		}
		if($("#type").val()==""){
			alert("कृपया मालाचा प्रकार निवडा");
			$("#type").focus();
			return;
		}
		if($("#hall").val()==""){
			alert("कृपया गोडावून निवडा");
			$("#hall").focus();
			return;
		}
		if($("#rate").val()==""){
			if(!confirm("आपण भाव टाकलेला नाही, तरीही पुढे जाऊ ईच्छिता का?")){
				$("#rate").focus();
				return;
			}
		}
		//append name and address to form before submit
		var name=$("#name").val();
		var address=$("#address").val();
		var mobile=$("#mobile").val();
		var rate=$("#rate").val();
		var hall=$("#hall").val();
		var type=$("#type").val();
		//1st way
		$('<input />').attr('type', 'hidden').attr('name', "name").attr('value', name).appendTo('#weights');
		//2nd way
		$("#weights").append('<input type="hidden" name="address" value="'+address+'" /> ');
		$("#weights").append('<input type="hidden" name="mobile" value="'+mobile+'" /> ');
		$("#weights").append('<input type="hidden" name="rate" value="'+rate+'" /> ');
		$("#weights").append('<input type="hidden" name="hall" value="'+hall+'" /> ');
		$("#weights").append('<input type="hidden" name="type" value="'+type+'" /> ');
		document.weights.submit();
	});
	$("#name").keyup(function(){
		localStorage.setItem('name',$(this).val());
	});
	$("#address").keyup(function(){
		localStorage.setItem('address',$(this).val());
	});
	$("#mobile").keyup(function(){
		localStorage.setItem('mobile',$(this).val());
	});
	$("#rate").keyup(function(){
		localStorage.setItem('rate',$(this).val());
	});
	$("#type").change(function(){
		localStorage.setItem('type',$(this).val());
	});
	$("#hall").change(function(){
		localStorage.setItem('hall',$(this).val());
	});
	
	$("#reset").click(function(){
		localStorage.clear();
		window.location.reload();
	});
	$("#add").click(function(){
		var no=$("#nos").val();
		no=Number(no);
		var nno=no+10;
		var html="<div class='col' style='margin-top:20px'>";
		for(var i=no+1;i<=no+10;i++){
			html=html+"<div class='form-group'> <label class='control-label col-sm-1'>"+i+")</label> <div class='col-sm-2'><input type='number' name='"+i+"' id='"+i+"' onkeyup='changed(this,"+nno+")' class='form-control' ></div></div>";
		}
		var newi=i-1;
		html=html+"<div class='form-group'> <label class='control-label col-sm-1'>Total</label> <div class='col-sm-2'> <input type='text' readonly name='total"+newi+"' id='total"+newi+"' value='0' class='form-control' readonly></div></div>";
		html=html+"</div>";
		$("#row").append(html);
		
		$("#nos").val(newi);
		localStorage.setItem('nos',newi);
		
		var a=localStorage.getItem('row');
		a=Number(a)+1;
		localStorage.setItem('row',a);
		
		activate();
	});
	//get name and address from localstorage
	var name=localStorage.getItem('name');
	if(name!=null){
		$("#name").val(name);
	}
	var address=localStorage.getItem('address');
	if(address!=null){
		$("#address").val(address);
	}
	var mobile=localStorage.getItem('mobile');
	if(mobile!=null){
		$("#mobile").val(mobile);
	}
	var rate=localStorage.getItem('rate');
	if(rate!=null){
		$("#rate").val(rate);
	}
	var type=localStorage.getItem('type');
	if(type!=null){
		$("#type").val(type);
	}
	var hall=localStorage.getItem('hall');
	if(hall!=null){
		$("#hall").val(hall);
	}
	//var final_total=localStorage.getItem('final_total');
	//if(final_total!=null){
	//	$("#final_total").val(final_total);
	//}
	
	
	var b=localStorage.getItem('nos');
	b=Number(b);
	if(b!=null && b!=""){
		$("#nos").val(b);
	}
	var a=localStorage.getItem('row');
	if(a==null){
		localStorage.setItem('row',1);
	}else{
		a=Number(a);
		if(a==1){
			//set localstorage to data
			for(var i=1;i<=10;i++){
				var c=localStorage.getItem(i);
				//alert(i+" "+c);
				if(c!=null){
					$("#"+i).val(c);
					$("#"+i).prop('readonly', true);
				}
			}
			var total10=localStorage.getItem("total10");
			$("#total10").val(total10);
			$("#final_total").val(total10);
		}
		else{
			//for first 10
			for(var i=1;i<=10;i++){
				var c=localStorage.getItem(i);
				//alert(i+" "+c);
				if(c!=null){
					$("#"+i).val(c);
					$("#"+i).prop('readonly', true);
				}
			}
			var total10=localStorage.getItem("total10");
			$("#total10").val(total10);
			//save first 10total as final total
			$("#final_total").val(total10);
			var final_total=Number(total10);
			var no=10;
			var nno=no+10;
			for(var j=2;j<=a;j++){
				var html="<div class='col' style='margin-top:20px'>";
				for(var i=no+1;i<=no+10;i++){
					//get localstorage fata and set to particular field
					var c=localStorage.getItem(i);
					if(c!=null){
						html=html+"<div class='form-group'> <label class='control-label col-sm-1'>"+i+")</label> <div class='col-sm-2'><input type='text' name='"+i+"' id='"+i+"' value='"+c+"' onchange='changed(this.value,"+nno+")' class='form-control' readonly ></div></div>";
					}else{
						html=html+"<div class='form-group'> <label class='control-label col-sm-1'>"+i+")</label> <div class='col-sm-2'><input type='text' name='"+i+"' id='"+i+"' onchange='changed(this.value,"+nno+")' class='form-control' ></div></div>";
					}
				}
				var newi=i-1;
				no=newi;
				nno=newi+10;
				html=html+"<div class='form-group'> <label class='control-label col-sm-1'>Total</label> <div class='col-sm-2'> <input type='text' readonly name='total"+newi+"' id='total"+newi+"' value='0' class='form-control' readonly></div></div>";
				html=html+"</div>";
				$("#row").append(html);
				//set total values
				var tot=localStorage.getItem("total"+j+"0");
				$("#total"+j+0).val(tot);
				//add this total to final total
				final_total=final_total+Number(tot);
			}
			$("#final_total").val(final_total);
		}
	}
	activate();
	
	//timer
	var date = new Date();
	var day = date.getDate();
	var options = { month: 'long'};
	var month=new Intl.DateTimeFormat('en-US', options).format(date);
	var year=date.getFullYear();
	var full_date=day+" "+month+" "+year;
	document.getElementById("date").innerHTML = full_date;
	var x = setInterval(function() {
	  // Get todays date and time
	  var now = new Date();
		var hour=now.getHours() % 12 || 12;
		var min=now.getMinutes();
		var sec=now.getSeconds();
		document.getElementById("time").innerHTML =hour+":"+min+":"+sec;
	}, 1000);
});
function changed(val,tot){
	if(val.value.length==2){
		id=Number(val.id)+1;
		if($("#" + id).length == 0) {
			$("#add").click();
		}
		$("#"+id).focus();
	}
	var total=0;
	//var val2=$('#total'+tot).val();
	var i=Number(tot)-9;
	for(;i<=tot;i++){
		var num=Number($("#"+i).val());
		if(num!=0){
			total=total+num;
			localStorage.setItem(i,num);
		}
	}
	$('#total'+tot).val(total);
	localStorage.setItem('total'+tot,total);
	
	//for final total
	var final_total=0;
	var no=localStorage.getItem('row');;
	//alert(no);
	for(var i=1;i<=no;i++){
		var a=$("#total"+i+0).val();
		final_total=final_total+Number(a);
	}
	$("#final_total").val(final_total);
}
</script>