<?php
require("../include/functions.php");
if(save_customer_deduct($_POST)){
	$id=$_POST['cid'];
	header('location:view.php?id='.$id);
	die();
}else{
	echo "Error";
	die();
	//header('location:list_customers.php?s=f');
	//die();
}
?>