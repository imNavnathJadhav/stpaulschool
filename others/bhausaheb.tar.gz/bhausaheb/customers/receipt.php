<?php
require("../include/check_user.php");
require("../include/functions.php");

$results=get_customers($_GET['id']);
if(!$results){
	header("location:../customers/list_customers.php");
}
$cal=get_customer_deduct($_GET['id']);
$row=$results->fetch_assoc();
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr" lang="en-MR" xml:lang="en-MR">
<head>
	<meta http-equiv="content-type" content="text/html; charset=UTF-8" /> 
	<meta http-equiv="content-language" content="en-MR" />
	<meta name="author" content="Navnath Jadhav" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<title>Bhausaheb Traders</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous" >
	<style type='text/css'>
	body {
	padding-bottom: 20px;
	}
	</style>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.2.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<div class="col-md-4">
			<b>भाऊसाहेब ट्रेडर्स</b><br>
			मांडगाव,<br>
			ता. सिल्लोड - 431135<br>
			+919096100647
		</div>
		<div class="col-md-4">
		</div>
		<div class="col-md-4">
			<b>चलन</b><br>
			पावती  # : <?=$_GET['id']?><br>
			तारीख : <?=date("d-m-Y h:i:s A")?><br>
			मालाचा प्रकार : <?=$row['types_name']?>
		</div>
		<div class="col-md-12">
		<div class="dropdown-divider"></div>
		</div>
		<div class="col-md-12">
		खातेदार<br>
		&nbsp;&nbsp;<?=$row['name']?><br>
		&nbsp;&nbsp;<?=$row['address']?><br>
		&nbsp;&nbsp;<?=$row['mobile']?><br>
		</div>
		<div class="col-md-12">
		<div class="dropdown-divider"></div>
		</div>
		<?php
		//echo "<pre>";
		$w=unserialize($row['weights']);
		//print_r($w);
		echo "<div class='col-sm' style='margin-top:2%'>";
		//$keys = array_keys($w);
		$array_keys=array_keys($w);
		$last=end($array_keys);
		foreach($w as $k=>$v){
			//echo $w[$k+1];
			if(!is_numeric($k)){
				$total="एकूण";
				echo "<div><span>$total <b style='color:red'>$v</b></span></div>";
				echo "</div>";
				if($k!==$last){
					echo "<div class='col-sm' style='margin-top:2%'>";
				}
			}else{
				$k=$k.")";
				echo "<div><span><b>$v</b></span></div>";
			}
		}
		?>
		<div class='col-sm-4' style='margin-top:2%'>
			<table class="table table-hover">
			<thead>
			<tbody>
			  <tr>
				<td>एकूण वजन :</td>
				<td style="text-align:right"><b><?=$row['final_weight']?></b></td>
				<td></td>
			  </tr>
			  <tr>
				<td>भाव :</td>
				<td  style="text-align:right"><b><?=$row['rate']?></td>
				<td></td>
			  </tr>
			  <tr>
				<td>एकूण रुपये :</td>
				<td style="text-align:right"><b>रु.<?=number_format((int)$row['price'])?></b> बाकी</td>
				<td>
				</td>
			  </tr>
			  <?php
				$total=(int)$row['price'];
				$minus=0;
				$plus=0;
			  $data=get_reductions($_GET['id']);
			  if($data){
				while($row = $data->fetch_assoc()) {
					$color="";
					$amount=$row['amount'];
					if($row['type']==2){
						$color="red";
						$amount="-".$amount;
						$minus+=$row['amount'];
					}elseif($row['type']==1){
						$plus+=$row['amount'];
					}
				?>
				<tr style="color:<?=$color?>">
					<td><?=$row['reason']. "&nbsp;(".date("d-m-Y h:i:s",strtotime($row['date'])).")"?></td>
					<td  style="text-align:right"><b><?php echo $amount?> रु.</b></td>
					<td></td>
				</tr>
				<?php
				}
			  $total+=$plus;
			  $total-=$minus;
			  $a="देणे बाकी";
			  if($total==0){
				  $a="निल";
			  }elseif($total<0){
				  $a="घेणे बाकी";
			  }
			  ?>
			  <tr>
				<td>रुपये :</td>
				<td style="text-align:right"><b>रु.<?=number_format($total)?></b><?="&nbsp;&nbsp;".$a?></td>
				<td></td>
			  </tr>
			  <?php
			  }
			  ?>
			</tbody>
		  </table>
		</div>
		<div class='col-sm-12' style='margin-top:4%'>
		<div class='row'>
		
		<div class='col-sm-4'>विक्रेता हस्ताक्षर</div>
		<div class='col-sm-4'></div>
		<div class='col-sm-4'>भाऊसाहेब ट्रेडर्स हस्ताक्षर</div>
		</div>
		</div>
		<div class='col-sm-12 text-center' style='margin-top:1%'>
		हे कॉम्प्युटर निर्माण बिल आहे
		</div>
	</div>
</div>
<?php
include("../include/footer.php");
?>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script>
$(document).ready(function(){
	window.print();
	window.close();
});
</script>