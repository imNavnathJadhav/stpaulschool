<?php
require("../include/head.php");
require("../include/functions.php");
$results=get_customers($_GET['id']);
if(!$results){
	header("location:../customers/index.php");
}
$c=$results->fetch_assoc();
$w=unserialize($c['weights']);
$types=get_types();
$halls=get_halls();
?>
<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css" />
<link rel="stylesheet" href="../assets/css/responsive.css" type="text/css" />
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<div class="form-horizontal">
			<div class="form-group">
			  <div class="col-xs-12">
				<div class="form-inline">
				  <div class="form-group">
					<input type="text" id="name" name="name" value="<?=$c['name']?>" class="form-control" placeholder="खातेदाराचे नाव" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" value="<?=$c['address']?>" id="address" name="address" placeholder="पत्ता" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" value="<?=$c['mobile']?>" name="mobile" id="mobile" placeholder="मोबाइल नंबर" />
				  </div>
				  <div class="form-group">
					<input type="text" class="form-control" value="<?=$c['rate']?>" name="rate" id="rate" value="" placeholder="भाव" />
				  </div>
				  <div class="form-group">
					<select class="form-control" name="type" id="type">
					<option value="">मालाचा प्रकार निवडा</option>
					<?php
					if($types){
					while($row = $types->fetch_assoc()) {
						?>
						<option value='<?=$row['id']?>' <?php if($c['type']==$row['id']){echo "selected";}?>><?=$row['name']?></option>
					<?php
					}
					}
					?>
					</select>
				  </div>
				  <div class="form-group">
					<select class="form-control" name="hall" id="hall">
					<option value="">गोडावून निवडा</option>
					<?php
					if($halls){
					while($row = $halls->fetch_assoc()) {
					?>
						<option value="<?=$row['id']?>" <?php if($c['hall']==$row['id']){echo "selected";}?>>
							<?=$row['name']." (".$row['location'].")"?>
						</option>
					<?php
					}
					}
					?>
					</select>
				  </div>
				  <div class="form-group">
					&nbsp;तारीख :&nbsp;<b><?=date('d-F-Y',strtotime($c['added_on']))?></b>&nbsp;&nbsp;वेळ  :&nbsp;<b><?=date('h:i:s A',strtotime($c['added_on']))?></b>
				  </div>
				</div>
			  </div>
			</div>
			<button class="btn btn-info" id="add">अधिक जोडा/Add Columns</button>
			<button class="btn btn-success" id="save">जतन करा/Save</button>
		</div>
	</div>
	<form role="form" action="save_edit_customer.php" class="form-inline" method="post" id="weights" name="weights">
		<div class="row" id="row">
			<?php
			$array_keys=array_keys($w);
			$no=count($array_keys)-2;
			$no2=count($array_keys)-1;
			$last=$array_keys[$no2];
			$lastsec=$array_keys[$no];
			?>
			<input type="hidden" id="nos" value="<?=$lastsec?>">
			<input type="hidden" name="cid" id="cid" value="<?=$c['id']?>">
			<div class="col" style="margin-top:20px">
				<?php
				$i=10;
				foreach($w as $k=>$v){
					if(is_numeric($k)){
						$lastnum=$k;
						?>
						<div class="form-group">
							<label class="control-label col-sm-1"><?=$k.")"?></label>
							<div class="col-sm-2">
								<input type="number" id="<?=$k?>" onkeyup="changed(this.value,<?=$i?>)" value="<?=$v?>" name="<?=$k?>" class="form-control" readonly >
							</div>
						</div>
					<?php }else{
						$i=$i+10;
						?>
						<div class="form-group">
							<label class="control-label col-sm-1">एकूण</label>
							<div class="col-sm-2">
								<input type="text" readonly name="<?=$k?>" value="<?=$v?>" id="<?=$k?>" class="form-control">
							</div>
						</div>
						</div>
						<?php if($k!==$last){?>
						<div class="col" style="margin-top:20px">
						<?php }?>
					<?php
					}
				}?>
		</div>
		<input type="hidden" id="lastnum" value="<?=$lastnum?>">
		<div class="col-sm-12">
		  <div class="form-group">
		  <label class="control-label col-md-3">एकूण वजन</label>
			<input type="text" name="final_total" id="final_total" class="form-control" value="<?=$c['final_weight']?>" readonly />
		  </div>
		</div>
	</form>
</div>
<?php
include("../include/footer.php");
?>
<script>
function activate(){
	$("input").focus(function(){
		$(this).prop('readonly', false);
	});
	$("input").blur(function(){
		$(this).prop('readonly', true);
	});
}
$(document).ready(function(){
	$("#save").click(function(){
		if($("#name").val()==""){
			alert("कृपया खातेदाराचे नाव टाका");
			$("#name").focus();
			return;
		}
		if($("#address").val()==""){
			alert("कृपया खातेदाराचा पत्ता टाका");
			$("#address").focus();
			return;
		}
		if($("#type").val()==""){
			alert("कृपया मालाचा प्रकार निवडा");
			$("#type").focus();
			return;
		}
		if($("#hall").val()==""){
			alert("कृपया गोडावून निवडा");
			$("#hall").focus();
			return;
		}
		if($("#rate").val()==""){
			if(!confirm("आपण भाव टाकलेला नाही, तरीही पुढे जाऊ ईच्छिता का?")){
				$("#rate").focus();
				return;
			}
		}
		
		var pass = prompt("कृपया तुमचा पासवर्ड टाका","");
		if(pass=="" || pass==null){
			return;
		}
		if(pass!="bhausahebuj"){
			alert("चुकीचा पासवर्ड !!! कृपया वैध पासवर्ड प्रविष्ट करा");
			return;
		}
		//append name and address to form before submit
		var name=$("#name").val();
		var address=$("#address").val();
		var mobile=$("#mobile").val();
		var rate=$("#rate").val();
		var hall=$("#hall").val();
		var type=$("#type").val();
		//1st way
		$('<input />').attr('type', 'hidden').attr('name', "name").attr('value', name).appendTo('#weights');
		//2nd way
		$("#weights").append('<input type="hidden" name="address" value="'+address+'" /> ');
		$("#weights").append('<input type="hidden" name="mobile" value="'+mobile+'" /> ');
		$("#weights").append('<input type="hidden" name="rate" value="'+rate+'" /> ');
		$("#weights").append('<input type="hidden" name="hall" value="'+hall+'" /> ');
		$("#weights").append('<input type="hidden" name="type" value="'+type+'" /> ');
		document.weights.submit();
	});
	
	$("#add").click(function(){
		var no=$("#nos").val();
		no=Number(no);
		var nno=no+10;
		var html="<div class='col' style='margin-top:20px'>";
		for(var i=no+1;i<=no+10;i++){
			html=html+"<div class='form-group'> <label class='control-label col-sm-1'>"+i+")</label> <div class='col-sm-2'><input type='number' name='"+i+"' id='"+i+"' onkeyup='changed(this.value,"+nno+")' class='form-control' readonly ></div></div>";
		}
		var newi=i-1;
		html=html+"<div class='form-group'> <label class='control-label col-sm-1'>Total</label> <div class='col-sm-2'> <input type='text' readonly name='total"+newi+"' id='total"+newi+"' value='0' class='form-control'></div></div>";
		html=html+"</div>";
		$("#row").append(html);
		$("#nos").val(newi);
		activate();
	});
	activate();
});
function changed(val,tot){
	var total=0;
	//var val2=$('#total'+tot).val();
	var i=Number(tot)-9;
	for(;i<=tot;i++){
		var num=Number($("#"+i).val());
		if(num!=0){
			total=total+num;
			//localStorage.setItem(i,num);
		}
	}
	$('#total'+tot).val(total);
	
	//localStorage.setItem('total'+tot,total);
	var a=$("#nos").val();
	var digit = a.toString()[0];
	digit=Number(digit);
	//for final total
	var final_total=0;
	//var no=localStorage.getItem('row');;
	//alert(no);
	for(var i=1;i<=digit;i++){
		var a=$("#total"+i+0).val();
		//alert(a);
		final_total=final_total+Number(a);
	}
	$("#final_total").val(final_total);
}
</script>