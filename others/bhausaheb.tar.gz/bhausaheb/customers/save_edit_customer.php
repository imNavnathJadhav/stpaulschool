<?php
if($_SERVER['REQUEST_METHOD']=="POST"){
	require("../include/functions.php");
	//echo "<pre>";
	//print_r($_POST);
	if(save_customer_edited_data($_POST)){
		header('location:index.php?e=s');
		die();
	}else{
		header('location:index.php?e=f');
		die();
	}
}
?>