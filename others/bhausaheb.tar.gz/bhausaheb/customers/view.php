<?php
require("../include/head.php");
require("../include/functions.php");

$results=get_customers($_GET['id']);
if(!$results){
	header("location:../customers/list_customers.php");
}
$cal=get_customer_deduct($_GET['id']);
$row=$results->fetch_assoc();
?>
<div class="container" style="top-margin:20px">
	<div class="row" style="margin-top:20px;">
		<div class="col-md-3">खातेदाराचे नाव : <b><?=$row['name']?></b></div>
		<div class="col-md-3">पत्ता : <b><?=$row['address']?></b></div>
		<div class="col-md-3">मोबाइल नंबर : <b><?=$row['mobile']?></b></div>
		<div class="col-md-2">मालाचा प्रकार : <b><?=$row['types_name']?></b></div>
		<div class="col-md-2"><b></b></div>
		<div class="col-md-4">गोडावून : <b><?=$row['halls_name']." (".$row['halls_location'].")"?></b></div>
		<div class="col-md-4">तारीख : <b><?=date('d-F-Y',strtotime($row['added_on']))?></b></div>
		<div class="col-md-2">वेळ : <b><?=date('h:i:s A',strtotime($row['added_on']))?></b>
		</div>
	</div>
	<div class="row" style="margin-top:20px;">
		<?php
		//echo "<pre>";
		$w=unserialize($row['weights']);
		//print_r($w);
		echo "<div class='col-sm-2' style='margin-top:2%'>";
		//$keys = array_keys($w);
		$array_keys=array_keys($w);
		$last=end($array_keys);
		foreach($w as $k=>$v){
			//echo $w[$k+1];
			if(!is_numeric($k)){
				$total="एकूण";
				echo "<div><span>$total <b style='color:red'>$v</b></span></div>";
				echo "</div>";
				if($k!==$last){
					echo "<div class='col-sm-2' style='margin-top:2%'>";
				}
			}else{
				$k=$k.")";
				echo "<div><span>$k <b>$v</b></span></div>";
			}
		}
		?>
	</div>
	<div class='row' style='margin-top:2%'>
		<table class="table table-hover">
			<thead>
			<tbody>
			  <tr>
				<td>एकूण वजन :</td>
				<td style="text-align:right"><b><?=$row['final_weight']?></b></td>
				<td></td>
			  </tr>
			  <tr>
				<td>भाव :</td>
				<td  style="text-align:right"><b><?=$row['rate']?></td>
				<td></td>
			  </tr>
			  <tr>
				<td>एकूण रुपये :</td>
				<td style="text-align:right"><b>रु.<?=number_format((int)$row['price'])?></b> बाकी</td>
				<td>
					<button type="button" onclick="document.getElementById('amtype').value=1" id="add" class="btn btn-info btn-sm" data-toggle="modal" data-target="#exampleModal"><span class="glyphicon glyphicon-plus"></span> +</button>
					<button type="button" onclick="document.getElementById('amtype').value=2" id="minus" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#exampleModal"><span class="glyphicon glyphicon-minus"></span> -</button>
				</td>
			  </tr>
			  <?php
				$total=(int)$row['price'];
				//echo $total;
				$minus=0;
				$plus=0;
			  $data=get_reductions($_GET['id']);
			  if($data){
				while($row = $data->fetch_assoc()) {
					$color="";
					$amount=$row['amount'];
					if($row['type']==2){
						$color="red";
						$amount="-".$amount;
						$minus+=$row['amount'];
					}elseif($row['type']==1){
						$plus+=$row['amount'];
					}
				?>
				<tr style="color:<?=$color?>">
					<td><?=$row['reason']. "&nbsp;(".date("d-m-Y h:i:s",strtotime($row['date'])).")"?></td>
					<td  style="text-align:right"><b><?php echo $amount?> रु.</b></td>
					<td></td>
				</tr>
				<?php
				}
			  $total+=$plus;
			  $total-=$minus;
			  $a="देणे बाकी";
			  if($total==0){
				  $a="निल";
			  }elseif($total<0){
				  $a="घेणे बाकी";
			  }
			  ?>
			  <tr>
				<td>रुपये :</td>
				<td style="text-align:right"><b>रु.<?=number_format($total)?></b><?="&nbsp;&nbsp;".$a?></td>
				<td></td>
			  </tr>
			  <?php
			  }
			  ?>
			</tbody>
		  </table>
	</div>
</div>
<?php
include("../include/footer.php");
?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">जोड आणि घटचे कारण</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form method="post" id="model_form" action="save_reductions.php">
		<input type="hidden" name="amtype" id="amtype" value="">
		<input type="hidden" name="cid" value="<?=$_GET['id']?>">
          <div class="form-group">
            <label for="amount" class="col-form-label">रुपये :</label>
            <input type="number" required class="form-control" name="am_amount" id="am_amount">
          </div>
          <div class="form-group">
            <label for="message-text" class="col-form-label">टीप :</label>
            <textarea class="form-control" name="note" id="message-text">उचल, नगदी, हमाली</textarea>
          </div>
		  <div class="form-group">
            <label for="date" class="col-form-label">तारीख व वेळ :</label>
            <input type="text" class="form-control" name="date" id="date" value="<?=date('Y-m-d H:i:s')?>">
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">बंद करा</button>
        <button type="submit" id="submit" class="btn btn-primary">जतन करा</button>
      </div>
    </div>
  </div>
</div>

<script>
$(document).ready(function(){
	$("#submit").click(function(){
		document.getElementById("model_form").submit();
	});
});
</script>