<?php
require("../include/head.php");
if(isset($_GET['s'])){
	if($_GET['s']=='s'){
		echo"<script>localStorage.clear();</script>";
		echo "<div style='text-align:center;font-size:17px' class='alert alert-success'><strong><span class='glyphicon glyphicon-ok'></span></strong> नवीन रेकॉर्ड यशस्वीपणे सेव झाला आहे.</div>";
	}elseif($_GET['s']=='f'){
		echo "<div style='text-align:center;font-size:17px' class='alert alert-danger'><strong><span class='glyphicon glyphicon-remove'></span></strong> नवीन रेकॉर्ड जोडण्यात अयशस्वी, कृपया इंटरनेट तपासा आणि पुन्हा प्रयत्न करा.</div>";
	}
}
if(isset($_GET['e'])){
	if($_GET['e']=='s'){
		echo "<div style='text-align:center;font-size:17px' class='alert alert-success'><strong><span class='glyphicon glyphicon-ok'></span></strong> रेकॉर्ड यशस्वीपणे सुधरला आहे.</div>";
	}elseif($_GET['e']=='f'){
		echo "<div style='text-align:center;font-size:17px' class='alert alert-danger'><strong><span class='glyphicon glyphicon-remove'></span></strong> रेकॉर्ड सुधरण्यात अयशस्वी, कृपया इंटरनेट तपासा आणि पुन्हा प्रयत्न करा.</div>";
	}
}
if(isset($_GET['d'])){
	if($_GET['d']=='s'){
		echo "<div style='text-align:center;font-size:17px' class='alert alert-success'><strong><span class='glyphicon glyphicon-ok'></span></strong> रेकॉर्ड  यशस्वीपणे काढुण टाकला आहे.</div>";
	}elseif($_GET['d']=='f'){
		echo "<div style='text-align:center;font-size:17px' class='alert alert-danger'><strong><span class='glyphicon glyphicon-remove'></span></strong> रेकॉर्ड काढण्यात अयशस्वी, कृपया इंटरनेट तपासा आणि पुन्हा प्रयत्न करा.</div>";
	}
}
require("../include/functions.php");
$results=get_halls();
?>
<style>
  td.highlight {
  background-color: whitesmoke !important;
}
</style>
<link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/fixedheader/3.1.5/css/fixedHeader.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap.min.css"/>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/select/1.2.7/css/select.dataTables.min.css"/>

<div class="main-content">
	<div class="main-content-inner">
		<div class="page-content">
			<div class="page-header">
				<h1>
					गोडावूनचे
					<small>
						<i class="ace-icon fa fa-angle-double-right"></i>
						अहवाल
					</small>
				</h1>
			</div><!-- /.page-header -->
			<div class="col-md-12">
			<table id="example" class="table table-striped table-bordered nowrap display" style="width:100%">
				<thead>
					<tr>
						<th>अनु. क्र.</th>
						<th>गोडावूनचे नाव</th>
						<th>ठिकाण</th>
						<th>तयार केलेली तारीख</th>
						<th>संपादित केलेली तारीख</th>
						<th>पर्याय</th>
					</tr>
				</thead>
			   <!-- <tfoot>
					<tr>
						<th>Name</th>
					</tr>
				</tfoot>-->
				<tbody>
					<?php
					if($results){
					while($row = $results->fetch_assoc()) { ?>
						<tr>
							<td><?=$row['id']?></td>
							<td><?=$row['name']?></td>
							<td><?=$row['location']?></td>
							<td><?=$row['created_on']?></td>
							<td><?=$row['updated_on']?></td>
							<td>
								<a title="संपादित करा" href="../halls/edit.php?id=<?=$row['id']?>"><i style="font-size:24px;" class="fa">&#xf044;</i></a>
								<a onclick="return confirm('आपणास हे रेकॉर्ड खात्रीने काढायाचा आहे का? एकदा काढल्यावर पुन्हा रिकव्हर केले जाणार नाही!!');" title="काढ" href="../halls/delete.php?id=<?=$row['id']?>"><i style="font-size:24px;color:red" class="fa">&#xf014;</i></a>
							</td>
						</tr>
					<?php
					}
					}
					?>
				</tbody>
			</table>
			</div>
		</div><!-- /.page-content -->
	</div><!-- main-content-inner -->
</div><!-- /.main-content -->
   
</div><!-- /.main-container -->
<?php
include("../include/footer.php");
?>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js" integrity="sha256-VazP97ZCwtekAsvgPBSUwPFKdrwD3unUfSGVYrahUqU=" crossorigin="anonymous"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script> 
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/fixedheader/3.1.5/js/dataTables.fixedHeader.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/select/1.2.7/js/dataTables.select.min.js"></script>
<script>
	$(document).ready(function() {
		var table = $('#example').DataTable( {
		responsive: true,
		select: {
			style: 'os',
			blurable: true
		}
	} );
	new $.fn.dataTable.FixedHeader( table );
	} );
</script>